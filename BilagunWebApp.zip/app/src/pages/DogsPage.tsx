import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollToTop } from '@/hooks/useScrollBehavior';
import { dogs, getDogsByCategory } from '@/data/dogs';
import type { DogCategory } from '@/data/dogs';
import Navbar from '@/components/Navbar';
import FooterSection from '@/sections/FooterSection';
import { ArrowLeft, Award, Calendar, Users } from 'lucide-react';

type FilterKey = DogCategory | 'all';

const filterTabs: { key: FilterKey; labelEs: string; labelEn: string; labelRu: string }[] = [
  { key: 'all', labelEs: 'Todos', labelEn: 'All', labelRu: 'Все' },
  { key: 'male', labelEs: 'Machos', labelEn: 'Males', labelRu: 'Кобели' },
  { key: 'female', labelEs: 'Hembras', labelEn: 'Females', labelRu: 'Суки' },
  { key: 'young', labelEs: 'Jóvenes Promesas', labelEn: 'Young Prospects', labelRu: 'Молодые таланты' },
  { key: 'puppy', labelEs: 'Cachorros', labelEn: 'Puppies', labelRu: 'Щенки' },
];

export default function DogsPage() {
  useScrollToTop();
  const { lang } = useLanguage();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<FilterKey>('all');

  const labelMap: Record<string, 'labelEs' | 'labelEn' | 'labelRu'> = {
    es: 'labelEs', en: 'labelEn', ru: 'labelRu',
  };
  const labelKey = labelMap[lang] || 'labelEs';

  const filtered = filter === 'all' ? dogs : getDogsByCategory(filter);

  return (
    <div className="bg-charcoal min-h-screen">
      <Navbar />

      <div className="pt-28 pb-20">
        <div className="container-main max-w-[1100px]">
          {/* Header */}
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-bone/50 hover:text-gold transition-colors mb-8 font-manrope text-sm"
          >
            <ArrowLeft size={18} /> {lang === 'es' ? 'Volver' : lang === 'en' ? 'Back' : 'Назад'}
          </button>

          <div className="text-center mb-10">
            <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-3">
              BILAGUN
            </span>
            <h1 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
              {lang === 'es' ? 'Nuestros Perros' : lang === 'en' ? 'Our Dogs' : 'Наши собаки'}
            </h1>
          </div>

          {/* Filter tabs */}
          <div className="flex flex-wrap justify-center gap-3 md:gap-4 mb-12">
            {filterTabs.map(tab => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className={`font-manrope text-xs uppercase tracking-wider px-5 py-2.5 rounded-lg border transition-all duration-300 ${
                  filter === tab.key
                    ? 'bg-gold text-charcoal border-gold font-semibold'
                    : 'text-bone/60 border-bone/15 hover:border-gold/40 hover:text-bone'
                }`}
              >
                {tab[labelKey]}
              </button>
            ))}
          </div>

          {/* Dog cards grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(dog => (
              <div
                key={dog.slug}
                className="group cursor-pointer"
                onClick={() => navigate(`/perro/${dog.slug}`)}
              >
                {/* Photo */}
                <div className="aspect-square overflow-hidden rounded-xl border border-gold/10 group-hover:border-gold/40 transition-all duration-500 bg-charcoal relative">
                  <img
                    src={dog.image}
                    alt={dog.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  {/* Quick info overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    <div className="flex items-center gap-3 text-bone/80 font-manrope text-xs">
                      <span className="flex items-center gap-1"><Calendar size={12} /> {dog.birthDate.split('-')[0]}</span>
                      <span className="flex items-center gap-1"><Award size={12} /> {dog.awards.length}</span>
                      <span className="flex items-center gap-1"><Users size={12} /> {dog.generation} Gen</span>
                    </div>
                  </div>
                </div>

                {/* Info below */}
                <div className="mt-4">
                  <div className="flex items-center gap-2">
                    <span className="font-cinzel text-lg text-bone group-hover:text-gold transition-colors">
                      {dog.name}
                    </span>
                    <span className={`w-2 h-2 rounded-full ${dog.gender === 'male' ? 'bg-gold' : 'bg-bone/40'}`} />
                  </div>
                  <p className="font-manrope text-xs text-bone/40 mt-1">
                    {dog.father} × {dog.mother}
                  </p>
                  <div className="flex gap-2 mt-2">
                    {dog.categories.map(cat => {
                      const labels: Record<string, string> = {
                        male: 'Macho', female: 'Hembra', young: 'Joven', puppy: 'Cachorro',
                      };
                      return (
                        <span key={cat} className="font-manrope text-[9px] uppercase tracking-wider text-gold/60 bg-gold/10 px-2 py-0.5 rounded-sm">
                          {labels[cat] || cat}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <p className="text-center text-bone/40 font-manrope mt-12">
              {lang === 'es' ? 'No hay perros en esta categoría.' : lang === 'en' ? 'No dogs in this category.' : 'Нет собак в этой категории.'}
            </p>
          )}
        </div>
      </div>

      <FooterSection />
    </div>
  );
}
