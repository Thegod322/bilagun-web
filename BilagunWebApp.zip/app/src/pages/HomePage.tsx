import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import Navbar from '@/components/Navbar';
import HeroSection from '@/sections/HeroSection';
import HistorySection from '@/sections/HistorySection';
import TreeSection from '@/sections/TreeSection';
import CharacterSection from '@/sections/CharacterSection';
import BreedSection from '@/sections/BreedSection';
import DogsPreviewSection from '@/sections/DogsPreviewSection';
import GallerySection from '@/sections/GallerySection';
import ArchiveSection from '@/sections/ArchiveSection';
import ContactSection from '@/sections/ContactSection';
import FooterSection from '@/sections/FooterSection';
import { useHomeScrollRestore } from '@/hooks/useScrollBehavior';

gsap.registerPlugin(ScrollTrigger);

export default function HomePage() {
  useHomeScrollRestore();

  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.08, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => { lenis.raf(time * 1000); });
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <div className="bg-charcoal min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <HistorySection />
        <TreeSection />
        <CharacterSection />
        <DogsPreviewSection />
        <BreedSection />
        <GallerySection />
        <ArchiveSection />
        <ContactSection />
      </main>
      <FooterSection />

      {/* Noise grain */}
      <svg className="fixed inset-0 w-full h-full pointer-events-none z-[9990] opacity-[0.025]">
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>

      {/* Gold veins */}
      <div className="fixed inset-0 pointer-events-none z-[1] opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(ellipse at 20% 50%, rgba(192,138,69,0.3) 0%, transparent 50%), radial-gradient(ellipse at 80% 80%, rgba(192,138,69,0.2) 0%, transparent 40%)' }} />
    </div>
  );
}
