import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useState } from 'react';
import { useScrollToTop } from '@/hooks/useScrollBehavior';
import { getDogBySlug } from '@/data/dogs';
import Navbar from '@/components/Navbar';
import FooterSection from '@/sections/FooterSection';
import { ArrowLeft, Award, Calendar, Users, Heart } from 'lucide-react';

export default function DogDetailPage() {
  useScrollToTop();
  const { slug } = useParams<{ slug: string }>();
  const { lang } = useLanguage();
  const navigate = useNavigate();
  const dog = getDogBySlug(slug || '');
  const [mainImage, setMainImage] = useState(0);

  if (!dog) {
    return (
      <div className="bg-charcoal min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-bone/50 font-manrope mb-4">
            {lang === 'es' ? 'Perro no encontrado' : lang === 'en' ? 'Dog not found' : 'Собака не найдена'}
          </p>
          <button onClick={() => navigate('/')} className="btn-primary">
            {lang === 'es' ? 'Volver al inicio' : lang === 'en' ? 'Back to home' : 'На главную'}
          </button>
        </div>
      </div>
    );
  }

  const description = lang === 'es' ? dog.description : lang === 'en' ? dog.descriptionEn : dog.descriptionRu;
  const genderLabel = dog.gender === 'male'
    ? (lang === 'es' ? 'Macho' : lang === 'en' ? 'Male' : 'Кобель')
    : (lang === 'es' ? 'Hembra' : lang === 'en' ? 'Female' : 'Сука');

  const genLabels: Record<string, Record<string, string>> = {
    es: { I: 'I Generación', II: 'II Generación', III: 'III Generación', IV: 'IV Generación', V: 'V Generación' },
    en: { I: 'I Generation', II: 'II Generation', III: 'III Generation', IV: 'IV Generation', V: 'V Generation' },
    ru: { I: 'I Поколение', II: 'II Поколение', III: 'III Поколение', IV: 'IV Поколение', V: 'V Поколение' },
  };
  const genLabel = genLabels[lang]?.[dog.generation] || `Gen ${dog.generation}`;

  return (
    <div className="bg-charcoal min-h-screen">
      <Navbar />

      {/* Full-width hero photo */}
      <div className="relative w-full h-[70vh] md:aspect-[16/9] md:h-auto lg:aspect-[21/9] overflow-hidden">
        <img
          src={dog.gallery[mainImage] || dog.image}
          alt={dog.name}
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay at bottom */}
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/20 to-transparent" />
        {/* Gradient overlay at top for nav */}
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/60 to-transparent" />

        {/* Back button - floating over the image */}
        <button
          onClick={() => navigate('/perros')}
          className="absolute top-20 left-4 md:left-8 z-10 flex items-center gap-2 text-bone/70 hover:text-gold transition-colors font-manrope text-sm bg-charcoal/40 backdrop-blur-sm px-4 py-2 rounded-full"
        >
          <ArrowLeft size={18} />
          {lang === 'es' ? 'Todos los perros' : lang === 'en' ? 'All dogs' : 'Все собаки'}
        </button>

        {/* Dog name overlay at bottom of image */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
          <span className="font-manrope text-[11px] uppercase tracking-[0.15em] text-gold/80">
            BILAGUN · {genLabel}
          </span>
          <h1 className="font-cinzel text-[36px] md:text-[56px] lg:text-[72px] text-bone leading-none mt-2">
            {dog.name}
          </h1>
          <div className="flex items-center gap-4 mt-3">
            <span className="font-manrope text-sm text-bone/60">{genderLabel}</span>
            <span className="w-1 h-1 rounded-full bg-gold/50" />
            <span className="font-cinzel text-sm text-gold">{dog.generation}</span>
          </div>
        </div>
      </div>

      {/* Thumbnails */}
      {dog.gallery.length > 1 && (
        <div className="container-main max-w-[600px] mx-auto -mt-8 relative z-10">
          <div className="flex justify-center gap-3 px-4">
            {dog.gallery.map((img, i) => (
              <button
                key={img}
                className={`w-16 h-16 md:w-20 md:h-20 rounded-lg overflow-hidden border-2 transition-all duration-300 flex-shrink-0 ${
                  i === mainImage
                    ? 'border-gold shadow-[0_0_16px_rgba(192,138,69,0.5)] scale-105'
                    : 'border-bone/15 hover:border-gold/40 opacity-70 hover:opacity-100'
                }`}
                onClick={() => setMainImage(i)}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Info content */}
      <div className="container-main max-w-[800px] mx-auto py-12 md:py-16 px-6">
        <div className="space-y-6">
          {/* LOE */}
          {dog.loe && (
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg border border-gold/20 flex items-center justify-center flex-shrink-0">
                <Award size={16} className="text-gold/70" />
              </div>
              <div>
                <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">LOE</span>
                <p className="font-manrope text-base text-bone mt-0.5">{dog.loe}</p>
              </div>
            </div>
          )}

          {/* Birth date */}
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg border border-gold/20 flex items-center justify-center flex-shrink-0">
              <Calendar size={16} className="text-gold/70" />
            </div>
            <div>
              <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">
                {lang === 'es' ? 'Fecha de nacimiento' : lang === 'en' ? 'Date of birth' : 'Дата рождения'}
              </span>
              <p className="font-manrope text-base text-bone mt-0.5">
                {new Date(dog.birthDate).toLocaleDateString(lang === 'es' ? 'es-ES' : lang === 'en' ? 'en-US' : 'ru-RU', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>

          {/* HD / ED */}
          {(dog.hd || dog.ed) && (
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg border border-gold/20 flex items-center justify-center flex-shrink-0">
                <Heart size={16} className="text-gold/70" />
              </div>
              <div>
                <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">HD / ED</span>
                <p className="font-manrope text-base text-bone mt-0.5">
                  {dog.hd || '—'} / {dog.ed || '—'}
                </p>
              </div>
            </div>
          )}

          {/* Parents */}
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg border border-gold/20 flex items-center justify-center flex-shrink-0">
              <Users size={16} className="text-gold/70" />
            </div>
            <div>
              <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">
                {lang === 'es' ? 'Padres' : lang === 'en' ? 'Parents' : 'Родители'}
              </span>
              <p className="font-manrope text-base text-bone mt-0.5">
                <span className="text-gold/70">{lang === 'es' ? 'Padre' : lang === 'en' ? 'Father' : 'Отец'}:</span> {dog.father}
              </p>
              <p className="font-manrope text-base text-bone mt-0.5">
                <span className="text-gold/70">{lang === 'es' ? 'Madre' : lang === 'en' ? 'Mother' : 'Мать'}:</span> {dog.mother}
              </p>
            </div>
          </div>

          {/* Description */}
          <div className="pt-4 border-t border-gold/10">
            <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">
              {lang === 'es' ? 'Descripción' : lang === 'en' ? 'Description' : 'Описание'}
            </span>
            <p className="font-manrope text-[15px] text-bone/70 leading-[1.8] mt-2">
              {description}
            </p>
          </div>

          {/* Awards */}
          {dog.awards.length > 0 && (
            <div className="pt-4 border-t border-gold/10">
              <span className="font-manrope text-[10px] uppercase tracking-[0.12em] text-bone/40">
                {lang === 'es' ? 'Nagradas y títulos' : lang === 'en' ? 'Awards and titles' : 'Награды и титулы'}
              </span>
              <div className="mt-3 space-y-2">
                {dog.awards.map((award, i) => (
                  <div key={i} className="flex items-center gap-3 py-3 border-b border-gold/5 last:border-b-0">
                    <div className="w-8 h-8 rounded-full bg-gold/15 flex items-center justify-center flex-shrink-0">
                      <Award size={14} className="text-gold" />
                    </div>
                    <span className="font-cinzel text-sm text-gold w-12 flex-shrink-0">{award.title}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-manrope text-sm text-bone/60 truncate">{award.event}</p>
                    </div>
                    <span className="font-manrope text-xs text-bone/30 flex-shrink-0">{award.year}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <FooterSection />
    </div>
  );
}
