import { Routes, Route } from 'react-router-dom';
import { LanguageProvider } from '@/context/LanguageContext';
import HomePage from '@/pages/HomePage';
import DogsPage from '@/pages/DogsPage';
import DogDetailPage from '@/pages/DogDetailPage';

export default function App() {
  return (
    <LanguageProvider>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/perros" element={<DogsPage />} />
        <Route path="/perro/:slug" element={<DogDetailPage />} />
      </Routes>
    </LanguageProvider>
  );
}
