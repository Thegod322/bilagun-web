export type { Language } from '@/context/LanguageContext';

const t = {
  es: {
    nav: { logo: 'BILAGUN', history: 'Historia', lineage: 'Linaje', gallery: 'Galería', archive: 'Archivo', contact: 'Contacto' },
    hero: {
      overline: 'Antigua dinastía de Pastores Alemanes',
      title: 'BILAGUN',
      subtitle: 'Una historia de lealtad, inteligencia y nobleza transmitida de generación en generación.',
      cta1: 'Explorar el linaje',
      cta2: 'Conocer la historia',
      scroll: 'Scroll',
    },
    history: {
      overline: '— 01 / Historia',
      title: 'Una dinastía nacida de la lealtad',
      text: 'BILAGUN representa una línea familiar de Pastores Alemanes donde cada generación conserva la fuerza, la inteligencia y el carácter noble de la raza. Más que un nombre, es un compromiso con la pureza del linaje y la preservación de las cualidades que hacen único al Pastor Alemán: lealtad inquebrantable, inteligencia superior y una nobleza que se transmite de sangre a sangre.',
    },
    tree: {
      overline: '— 02 / Linaje',
      title: 'Árbol de generaciones',
      subtitle: 'Cada rama conserva una historia. Cada nombre forma parte del legado BILAGUN.',
      gen1: 'I Generación',
      gen2: 'II Generación',
      gen3: 'III Generación',
      gen4: 'IV Generación',
    },
    character: {
      overline: '— 03 / Carácter',
      title: 'Carácter, equilibrio y nobleza',
      traits: [
        { title: 'Lealtad', desc: 'Vínculo inquebrantable con su familia. Protector natural.' },
        { title: 'Inteligencia', desc: 'Capacidad de aprendizaje excepcional. Rápido, intuitivo, obediente.' },
        { title: 'Protección', desc: 'Instinto guardián sin agresividad. Presencia que disuade.' },
        { title: 'Equilibrio', desc: 'Temperamento sereno. Fuerza contenida y nobleza en cada gesto.' },
        { title: 'Memoria de linaje', desc: 'Cada generación porta el legado. Sangre que recuerda su origen.' },
      ],
    },
    breed: {
      overline: '— 04 / La Raza',
      title: 'El alma del Pastor Alemán',
      text: 'El Pastor Alemán es una raza reconocida por su inteligencia, capacidad de aprendizaje, instinto protector y profunda conexión con la familia. Su versatilidad lo ha convertido en compañero de trabajo, protector del hogar y miembro inseparable de quienes lo rodean.',
    },
    gallery: {
      overline: '— 05 / Galería',
      title: 'Momentos del linaje',
      filters: { all: 'Todos', portraits: 'Retratos', nature: 'Naturaleza', shows: 'Exposiciones' },
    },
    archive: {
      overline: '— 06 / Archivo',
      title: 'Archivo de la dinastía',
      stats: [
        { value: '25+', label: 'Años de linaje' },
        { value: '100+', label: 'Exposiciones' },
        { value: '50+', label: 'Títulos' },
        { value: '15+', label: 'Países' },
      ],
    },
    contact: {
      overline: '— 07 / Contacto',
      title: 'Contacto',
      text: 'Si quieres conocer más sobre la historia BILAGUN, su linaje o sus futuras generaciones, puedes ponerte en contacto con nosotros.',
      form: { name: 'Nombre', email: 'Email', message: 'Mensaje', submit: 'Enviar mensaje', success: 'Mensaje enviado. Gracias.' },
    },
    footer: {
      tagline: 'No es solo un perro. Es un linaje.',
      copyright: '© 2025 BILAGUN. Todos los derechos reservados.',
    },
  },
  en: {
    nav: { logo: 'BILAGUN', history: 'History', lineage: 'Lineage', gallery: 'Gallery', archive: 'Archive', contact: 'Contact' },
    hero: {
      overline: 'Ancient German Shepherd Dynasty',
      title: 'BILAGUN',
      subtitle: 'A story of loyalty, intelligence and nobility passed down from generation to generation.',
      cta1: 'Explore the lineage',
      cta2: 'Discover the history',
      scroll: 'Scroll',
    },
    history: {
      overline: '— 01 / History',
      title: 'A dynasty born of loyalty',
      text: 'BILAGUN represents a family line of German Shepherds where each generation preserves the strength, intelligence and noble character of the breed. More than a name, it is a commitment to the purity of the bloodline and the preservation of the qualities that make the German Shepherd unique: unwavering loyalty, superior intelligence and a nobility transmitted from blood to blood.',
    },
    tree: {
      overline: '— 02 / Lineage',
      title: 'Family tree',
      subtitle: 'Each branch preserves a story. Every name is part of the BILAGUN legacy.',
      gen1: 'I Generation',
      gen2: 'II Generation',
      gen3: 'III Generation',
      gen4: 'IV Generation',
    },
    character: {
      overline: '— 03 / Character',
      title: 'Character, balance and nobility',
      traits: [
        { title: 'Loyalty', desc: 'Unbreakable bond with family. Natural protector.' },
        { title: 'Intelligence', desc: 'Exceptional learning ability. Fast, intuitive, obedient.' },
        { title: 'Protection', desc: 'Guardian instinct without aggression. A presence that deters.' },
        { title: 'Balance', desc: 'Serene temperament. Contained strength and nobility in every gesture.' },
        { title: 'Lineage memory', desc: 'Each generation carries the legacy. Blood that remembers its origin.' },
      ],
    },
    breed: {
      overline: '— 04 / The Breed',
      title: 'The soul of the German Shepherd',
      text: 'The German Shepherd is a breed recognized for its intelligence, learning ability, protective instinct and deep connection with the family. Its versatility has made it a work companion, home guardian and inseparable member of those around it.',
    },
    gallery: {
      overline: '— 05 / Gallery',
      title: 'Moments of the lineage',
      filters: { all: 'All', portraits: 'Portraits', nature: 'Nature', shows: 'Shows' },
    },
    archive: {
      overline: '— 06 / Archive',
      title: 'Dynasty archive',
      stats: [
        { value: '25+', label: 'Years of lineage' },
        { value: '100+', label: 'Shows' },
        { value: '50+', label: 'Titles' },
        { value: '15+', label: 'Countries' },
      ],
    },
    contact: {
      overline: '— 07 / Contact',
      title: 'Contact',
      text: 'If you want to know more about the BILAGUN history, its lineage or future generations, you can get in touch with us.',
      form: { name: 'Name', email: 'Email', message: 'Message', submit: 'Send message', success: 'Message sent. Thank you.' },
    },
    footer: {
      tagline: 'It is not just a dog. It is a bloodline.',
      copyright: '© 2025 BILAGUN. All rights reserved.',
    },
  },
  ru: {
    nav: { logo: 'BILAGUN', history: 'История', lineage: 'Родословная', gallery: 'Галерея', archive: 'Архив', contact: 'Контакты' },
    hero: {
      overline: 'Древняя династия немецких овчарок',
      title: 'BILAGUN',
      subtitle: 'История верности, интеллекта и благородства, передаваемая из поколения в поколение.',
      cta1: 'Исследовать род',
      cta2: 'Узнать историю',
      scroll: 'Скролл',
    },
    history: {
      overline: '— 01 / История',
      title: 'Династия, рождённая верностью',
      text: 'BILAGUN — это семейная линия немецких овчарок, где каждое поколение сохраняет силу, интеллект и благородный характер породы. Это не просто имя — это обязательство перед чистотой родословной и сохранением тех качеств, которые делают немецкую овчарку уникальной: непоколебимая верность, превосходный интеллект и благородство, передаваемое из крови в кровь.',
    },
    tree: {
      overline: '— 02 / Родословная',
      title: 'Древо поколений',
      subtitle: 'Каждая ветвь хранит историю. Каждое имя — часть наследия BILAGUN.',
      gen1: 'I Поколение',
      gen2: 'II Поколение',
      gen3: 'III Поколение',
      gen4: 'IV Поколение',
    },
    character: {
      overline: '— 03 / Характер',
      title: 'Характер, равновесие и благородство',
      traits: [
        { title: 'Верность', desc: 'Нерушимая связь с семьёй. Прирождённый защитник.' },
        { title: 'Интеллект', desc: 'Исключительная способность к обучению. Быстрый, интуитивный, послушный.' },
        { title: 'Защита', desc: 'Инстинкт стража без агрессии. Присутствие, которое удерживает.' },
        { title: 'Равновесие', desc: 'Спокойный темперамент. Сдержанная сила и благородство в каждом движении.' },
        { title: 'Память рода', desc: 'Каждое поколение несёт наследие. Кровь, которая помнит своё начало.' },
      ],
    },
    breed: {
      overline: '— 04 / Порода',
      title: 'Душа немецкой овчарки',
      text: 'Немецкая овчарка — порода, признанная за свой интеллект, способность к обучению, защитный инстинкт и глубокую связь с семьёй. Её универсальность сделала её рабочим компаньоном, хранителем дома и неотъемлемым членом семьи.',
    },
    gallery: {
      overline: '— 05 / Галерея',
      title: 'Моменты рода',
      filters: { all: 'Все', portraits: 'Портреты', nature: 'Природа', shows: 'Выставки' },
    },
    archive: {
      overline: '— 06 / Архив',
      title: 'Архив династии',
      stats: [
        { value: '25+', label: 'Лет рода' },
        { value: '100+', label: 'Выставок' },
        { value: '50+', label: 'Титулов' },
        { value: '15+', label: 'Стран' },
      ],
    },
    contact: {
      overline: '— 07 / Контакты',
      title: 'Контакты',
      text: 'Если вы хотите узнать больше об истории BILAGUN, её родословной или будущих поколениях, свяжитесь с нами.',
      form: { name: 'Имя', email: 'Email', message: 'Сообщение', submit: 'Отправить', success: 'Сообщение отправлено. Спасибо.' },
    },
    footer: {
      tagline: 'Это не просто собака. Это род.',
      copyright: '© 2025 BILAGUN. Все права защищены.',
    },
  },
};

export default t;
