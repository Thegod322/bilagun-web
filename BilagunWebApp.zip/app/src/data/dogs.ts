export type DogGender = 'male' | 'female';
export type DogCategory = 'male' | 'female' | 'young' | 'puppy';

export interface Dog {
  slug: string;
  name: string;
  gender: DogGender;
  categories: DogCategory[];
  birthDate: string;
  father: string;
  mother: string;
  description: string;
  descriptionEn: string;
  descriptionRu: string;
  awards: { title: string; year: string; event: string }[];
  image: string;
  gallery: string[];
  generation: string;
  loe?: string;
  color?: string;
  hd?: string;
  ed?: string;
  survey?: string;
}

export const dogs: Dog[] = [
  {
    slug: 'juma',
    name: 'Juma de Bi Lagun',
    gender: 'female',
    categories: ['female'],
    birthDate: '2009-06-18',
    father: 'VA Nilo vom Römerland',
    mother: 'Quila vom Gleisdreieck',
    description: 'Juma de Bi Lagun es la matriarca fundadora de la dinastía BILAGUN. Hembra excepcional con número de registro LOE 1885611 y SZ 9162328. Nacida el 18 de junio de 2009, de color dorado negro (sgA) con pelaje corto (Stockhaar). Obtuvo la calificación VA(E) en exposición y el título SchH1 en trabajo. Cadera y codo normales (HD/ED: Normal/Normal). Es la madre de toda la dinastía BILAGUN.',
    descriptionEn: 'Juma de Bi Lagun is the founding matriarch of the BILAGUN dynasty. Exceptional female with registration number LOE 1885611 and SZ 9162328. Born June 18, 2009, black and gold (sgA) with short coat (Stockhaar). Achieved VA(E) rating in shows and SchH1 working title. Normal hips and elbows (HD/ED: Normal/Normal). Mother of the entire BILAGUN dynasty.',
    descriptionRu: 'Juma de Bi Lagun — основательница-матриарх династии BILAGUN. Исключительная сука с регистрационным номером LOE 1885611 и SZ 9162328. Родилась 18 июня 2009, чёрно-подпалая (sgA), короткая шерсть (Stockhaar). Получила оценку VA(E) на выставках и рабочий титул SchH1. Нормальные тазобедренный и локтевой суставы (HD/ED: Normal/Normal). Мать всей династии BILAGUN.',
    awards: [
      { title: 'VA(E)', year: '2009', event: 'Exposición del Pastor Alemán' },
      { title: 'SchH1', year: '2009', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-argo.jpg',
    gallery: ['/assets/tree-argo.jpg', '/assets/gallery-4.jpg'],
    generation: 'I',
    loe: '1885611',
    color: 'sgA',
    hd: 'Normal',
    ed: 'Normal',
    survey: 'Kkl. 1',
  },
  {
    slug: 'yuma',
    name: 'Yuma de Bi Lagun',
    gender: 'female',
    categories: ['female'],
    birthDate: '2011-05-12',
    father: 'Hektor vom Kastanienhof',
    mother: 'Juma de Bi Lagun',
    description: 'Yuma de Bi Lagun es hija de Juma y continúa el legado familiar. LOE 2019472, SZ 9168228. Nacida el 12 de mayo de 2011, de color negro dorado (sb), pelo corto. Calificación V en exposición, título IPO1 en trabajo. Cadera y codo normales. Madre de Korah, Kiss, Kuma, Russo, Halfa (Solo y Owen) y Kenzo.',
    descriptionEn: 'Yuma de Bi Lagun is daughter of Juma and continues the family legacy. LOE 2019472, SZ 9168228. Born May 12, 2011, black and gold (sb), short coat. V rating in shows, IPO1 working title. Normal hips and elbows. Mother of Korah, Kiss, Kuma, Russo, Halfa (Solo and Owen) and Kenzo.',
    descriptionRu: 'Yuma de Bi Lagun — дочь Juma, продолжает семейное наследие. LOE 2019472, SZ 9168228. Родилась 12 мая 2011, чёрно-подпалая (sb), короткая шерсть. Оценка V на выставках, рабочий титул IPO1. Нормальные тазобедренный и локтевой суставы. Мать Korah, Kiss, Kuma, Russo, Halfa (Solo и Owen) и Kenzo.',
    awards: [
      { title: 'V', year: '2011', event: 'Exposición del Pastor Alemán' },
      { title: 'IPO1', year: '2011', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-nora.jpg',
    gallery: ['/assets/tree-nora.jpg', '/assets/gallery-2.jpg'],
    generation: 'II',
    loe: '2019472',
    color: 'sb',
    hd: 'Normal',
    ed: 'Normal',
  },
  {
    slug: 'kenzo',
    name: 'Kenzo de Bi Lagun',
    gender: 'male',
    categories: ['male'],
    birthDate: '2015-04-10',
    father: 'Hektor vom Kastanienhof',
    mother: 'Yuma de Bi Lagun',
    description: 'Kenzo de Bi Lagun es hijo de Yuma de Bi Lagun. Pastor Alemán macho con pelaje corto, calificación AK(E) y SG en exposición. Título IPO1 en pruebas de trabajo. Cadera casi normal y codo casi normal. Miembro destacado de la segunda generación de la dinastía.',
    descriptionEn: 'Kenzo de Bi Lagun is son of Yuma de Bi Lagun. German Shepherd male with short coat, AK(E) and SG show rating. IPO1 working title. Fast normal hips and elbows. Outstanding member of the second generation of the dynasty.',
    descriptionRu: 'Kenzo de Bi Lagun — сын Yuma de Bi Lagun. Немецкая овчарка, короткая шерсть, оценка AK(E) и SG на выставках. Рабочий титул IPO1. Почти нормальные тазобедренный и локтевой суставы. Выдающийся член второго поколения династии.',
    awards: [
      { title: 'AK(E)', year: '2015', event: 'Exposición del Pastor Alemán' },
      { title: 'SG', year: '2015', event: 'Monográfica' },
      { title: 'IPO1', year: '2015', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-max.jpg',
    gallery: ['/assets/tree-max.jpg', '/assets/gallery-4.jpg'],
    generation: 'II',
    hd: 'Fast Normal',
    ed: 'Fast Normal',
  },
  {
    slug: 'korah',
    name: 'Korah de Bi Lagun',
    gender: 'male',
    categories: ['male'],
    birthDate: '2013-01-18',
    father: 'Hektor vom Kastanienhof',
    mother: 'Yuma de Bi Lagun',
    description: 'Korah de Bi Lagun es hijo de Yuma, hermano de Kenzo, Kiss y los demás. Pastor Alemán macho con calificación V en exposición y título IPO1 en trabajo.',
    descriptionEn: 'Korah de Bi Lagun is son of Yuma, brother of Kenzo, Kiss and others. German Shepherd male with V rating in shows and IPO1 working title.',
    descriptionRu: 'Korah de Bi Lagun — сын Yuma, брат Kenzo, Kiss и остальных. Немецкая овчарка, оценка V на выставках, рабочий титул IPO1.',
    awards: [
      { title: 'V', year: '2013', event: 'Exposición del Pastor Alemán' },
      { title: 'IPO1', year: '2013', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-rex.jpg',
    gallery: ['/assets/tree-rex.jpg', '/assets/gallery-1.jpg'],
    generation: 'II',
  },
  {
    slug: 'kiss',
    name: 'Kiss de Bi Lagun',
    gender: 'female',
    categories: ['female'],
    birthDate: '2013-01-18',
    father: 'Hektor vom Kastanienhof',
    mother: 'Yuma de Bi Lagun',
    description: 'Kiss de Bi Lagun es hija de Yuma, hembra de Pastor Alemán. Calificación AK(E) y SG en exposición. Título IPO1 en trabajo. Cadera y codo normales.',
    descriptionEn: 'Kiss de Bi Lagun is daughter of Yuma, German Shepherd female. AK(E) and SG show rating. IPO1 working title. Normal hips and elbows.',
    descriptionRu: 'Kiss de Bi Lagun — дочь Yuma, немецкая овчарка. Оценка AK(E) и SG на выставках. Рабочий титул IPO1. Нормальные тазобедренный и локтевой суставы.',
    awards: [
      { title: 'AK(E)', year: '2013', event: 'Exposición del Pastor Alemán' },
      { title: 'SG', year: '2013', event: 'Monográfica' },
      { title: 'IPO1', year: '2013', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-alba.jpg',
    gallery: ['/assets/tree-alba.jpg', '/assets/gallery-6.jpg'],
    generation: 'II',
    hd: 'Normal',
    ed: 'Normal',
  },
  {
    slug: 'halfa',
    name: 'Halfa de Bi Lagun',
    gender: 'female',
    categories: ['female'],
    birthDate: '2014-02-22',
    father: 'Hektor vom Kastanienhof',
    mother: 'Yuma de Bi Lagun',
    description: 'Halfa de Bi Lagun es hija de Yuma, hembra de Pastor Alemán. Calificación AK(P) y SG en exposición. Título IPO1 en trabajo. Cadera y codo normales. Madre de Solo y Owen.',
    descriptionEn: 'Halfa de Bi Lagun is daughter of Yuma, German Shepherd female. AK(P) and SG show rating. IPO1 working title. Normal hips and elbows. Mother of Solo and Owen.',
    descriptionRu: 'Halfa de Bi Lagun — дочь Yuma, немецкая овчарка. Оценка AK(P) и SG на выставках. Рабочий титул IPO1. Нормальные тазобедренный и локтевой суставы. Мать Solo и Owen.',
    awards: [
      { title: 'AK(P)', year: '2014', event: 'Exposición del Pastor Alemán' },
      { title: 'SG', year: '2014', event: 'Monográfica' },
      { title: 'IPO1', year: '2014', event: 'Prueba de Trabajo' },
    ],
    image: '/assets/tree-luna.jpg',
    gallery: ['/assets/tree-luna.jpg', '/assets/gallery-5.jpg'],
    generation: 'II',
    hd: 'Normal',
    ed: 'Normal',
  },
  {
    slug: 'solo',
    name: 'Solo de Bi Lagun',
    gender: 'male',
    categories: ['male', 'young'],
    birthDate: '2018-03-15',
    father: 'Tabo v. Zellwaldrand',
    mother: 'Halfa de Bi Lagun',
    description: 'Solo de Bi Lagun es hijo de Halfa, nieto de Yuma. Pastor Alemán macho de la tercera generación de la dinastía BILAGUN. Joven promesa con gran potencial.',
    descriptionEn: 'Solo de Bi Lagun is son of Halfa, grandson of Yuma. German Shepherd male of the third generation of the BILAGUN dynasty. Young prospect with great potential.',
    descriptionRu: 'Solo de Bi Lagun — сын Halfa, внук Yuma. Немецкая овчарка, третье поколение династии BILAGUN. Молодой талант с большим потенциалом.',
    awards: [],
    image: '/assets/kenzo-card.jpg',
    gallery: ['/assets/kenzo-card.jpg', '/assets/gallery-4.jpg'],
    generation: 'III',
  },
  {
    slug: 'owen',
    name: 'Owen de Bi Lagun',
    gender: 'male',
    categories: ['male', 'young'],
    birthDate: '2018-03-15',
    father: 'Tabo v. Zellwaldrand',
    mother: 'Halfa de Bi Lagun',
    description: 'Owen de Bi Lagun es hijo de Halfa, nieto de Yuma y hermano de Solo. Pastor Alemán macho de la tercera generación. Destaca por su temperamento equilibrado y estructura sólida.',
    descriptionEn: 'Owen de Bi Lagun is son of Halfa, grandson of Yuma and brother of Solo. German Shepherd male of the third generation. Known for balanced temperament and solid structure.',
    descriptionRu: 'Owen de Bi Lagun — сын Halfa, внук Yuma и брат Solo. Немецкая овчарка, третье поколение. Известен сбалансированным темпераментом и крепким строением.',
    awards: [],
    image: '/assets/marck-card.jpg',
    gallery: ['/assets/marck-card.jpg', '/assets/gallery-1.jpg'],
    generation: 'III',
  },
  {
    slug: 'farah',
    name: 'Farah de Bi Lagun',
    gender: 'female',
    categories: ['female'],
    birthDate: '2010-09-12',
    father: 'Hektor vom Kastanienhof',
    mother: 'Juma de Bi Lagun',
    description: 'Farah de Bi Lagun es hija de Juma, hermana de Yuma. Hembra de Pastor Alemán de la primera camada de Juma. Madre de Raisha de Arances y Owen.',
    descriptionEn: 'Farah de Bi Lagun is daughter of Juma, sister of Yuma. German Shepherd female from Juma\'s first litter. Mother of Raisha de Arances and Owen.',
    descriptionRu: 'Farah de Bi Lagun — дочь Juma, сестра Yuma. Немецкая овчарка из первого помёта Juma. Мать Raisha de Arances и Owen.',
    awards: [],
    image: '/assets/gallery-2.jpg',
    gallery: ['/assets/gallery-2.jpg', '/assets/gallery-5.jpg'],
    generation: 'I',
  },
];

export function getDogBySlug(slug: string): Dog | undefined {
  return dogs.find(d => d.slug === slug);
}

export function getDogsByCategory(cat: DogCategory): Dog[] {
  return dogs.filter(d => d.categories.includes(cat));
}

export function getAwardsByYear(): Record<string, { title: string; year: string; event: string; dogName: string }[]> {
  const result: Record<string, { title: string; year: string; event: string; dogName: string }[]> = {};
  dogs.forEach(dog => {
    dog.awards.forEach(award => {
      if (!result[award.year]) result[award.year] = [];
      result[award.year].push({ ...award, dogName: dog.name });
    });
  });
  const sorted: Record<string, { title: string; year: string; event: string; dogName: string }[]> = {};
  Object.keys(result).sort((a, b) => parseInt(b) - parseInt(a)).forEach(year => {
    sorted[year] = result[year];
  });
  return sorted;
}
