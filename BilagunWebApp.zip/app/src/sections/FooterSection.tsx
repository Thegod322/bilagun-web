import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';

export default function FooterSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const navigate = useNavigate();

  return (
    <footer className="py-12 md:py-16 bg-charcoal border-t border-gold/10">
      <div className="container-main">
        <div className="flex flex-col items-center text-center">
          <span className="font-cinzel text-2xl md:text-3xl tracking-[0.1em] text-bone">
            BILAGUN
          </span>
          <p className="mt-4 font-cinzel text-sm text-gold/60 italic">
            {t.footer.tagline}
          </p>

          <div className="mt-8 w-24 gold-divider" />

          <div className="mt-8 flex flex-wrap justify-center gap-6 md:gap-8">
            {(['history', 'lineage', 'gallery', 'contact'] as const).map(key => (
              <button
                key={key}
                onClick={() => {
                  const id = key === 'lineage' ? 'tree' : key;
                  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="font-manrope text-[11px] uppercase tracking-[0.1em] text-bone/40 hover:text-gold transition-colors"
              >
                {t.nav[key]}
              </button>
            ))}
            <button
              onClick={() => navigate('/perros')}
              className="font-manrope text-[11px] uppercase tracking-[0.1em] text-bone/40 hover:text-gold transition-colors"
            >
              {lang === 'es' ? 'Perros' : lang === 'en' ? 'Dogs' : 'Собаки'}
            </button>
          </div>

          <p className="mt-10 font-manrope text-[11px] text-bone/25">
            {t.footer.copyright}
          </p>
        </div>
      </div>
    </footer>
  );
}
