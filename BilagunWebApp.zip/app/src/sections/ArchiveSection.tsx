import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import { getAwardsByYear } from '@/data/dogs';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function ArchiveSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const sectionRef = useRef<HTMLElement>(null);
  const countersRef = useRef<(HTMLSpanElement | null)[]>([]);
  const [expandedYear, setExpandedYear] = useState<string | null>(null);

  const awardsByYear = getAwardsByYear();
  const years = Object.keys(awardsByYear);
  const stats = t.archive.stats;

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    gsap.fromTo(el.querySelector('.archive-header'), { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });

    countersRef.current.forEach((counter, i) => {
      if (!counter) return;
      const target = parseInt(stats[i].value);
      const obj = { val: 0 };
      gsap.to(obj, {
        val: target, duration: 1.8, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 60%' },
        delay: i * 0.15,
        onUpdate: () => { counter.textContent = Math.round(obj.val) + '+'; }
      });
    });

    const yearGroups = el.querySelectorAll('.year-group');
    gsap.fromTo(yearGroups, { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.15, ease: 'power3.out',
      scrollTrigger: { trigger: el.querySelector('.awards-list'), start: 'top 80%' }
    });
  }, [lang]);

  const toggleYear = (year: string) => {
    setExpandedYear(prev => prev === year ? null : year);
  };

  return (
    <section id="archive" ref={sectionRef} className="py-24 md:py-32 bg-charcoal overflow-hidden">
      <div className="container-main max-w-[1100px]">
        <div className="archive-header text-center mb-16">
          <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
            {t.archive.overline}
          </span>
          <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
            {t.archive.title}
          </h2>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, i) => (
            <div key={stat.label} className="text-center relative">
              <span ref={(el) => { countersRef.current[i] = el; }} className="font-cinzel text-[40px] md:text-[52px] text-gradient-gold leading-none">
                0+
              </span>
              <p className="mt-2 font-manrope text-[11px] uppercase tracking-[0.12em] text-bone/45">{stat.label}</p>
              {i < stats.length - 1 && <div className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-px h-10 bg-gold/10" />}
            </div>
          ))}
        </div>

        {/* Awards grouped by year — dropdown, NO outer borders */}
        <div className="awards-list">
          {years.map(year => {
            const isOpen = expandedYear === year;
            return (
              <div key={year} className="year-group">
                {/* Year header — clickable row */}
                <button
                  onClick={() => toggleYear(year)}
                  className="w-full flex items-center gap-4 py-5 px-2 text-left hover:bg-gold/5 transition-colors border-b border-gold/10"
                >
                  <span className="font-cinzel text-2xl md:text-3xl text-gold w-20 flex-shrink-0">{year}</span>
                  <div className="flex-1 h-px bg-gold/15" />
                  <span className="font-manrope text-xs text-bone/40 flex-shrink-0">
                    {awardsByYear[year].length} {lang === 'es' ? 'títulos' : lang === 'en' ? 'titles' : 'титулов'}
                  </span>
                  <ChevronDown
                    size={20}
                    className={`text-gold/60 flex-shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                  />
                </button>

                {/* Awards list — collapsible, full width, minimal style */}
                <div
                  className={`overflow-hidden transition-all duration-400 ease-out ${isOpen ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'}`}
                >
                  {awardsByYear[year].map((award, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-4 py-4 px-2 w-full hover:bg-gold/[0.03] transition-colors border-b border-gold/5 last:border-b-0"
                    >
                      <div className="w-8 h-8 rounded-full bg-gold/15 flex items-center justify-center flex-shrink-0">
                        <Award size={13} className="text-gold" />
                      </div>
                      <span className="font-cinzel text-base md:text-lg text-gold w-14 flex-shrink-0">{award.title}</span>
                      <div className="flex-1 min-w-0">
                        <p className="font-manrope text-sm text-bone/70 truncate">{award.event}</p>
                      </div>
                      <span className="font-manrope text-xs text-bone/30 flex-shrink-0 hidden sm:block">{award.dogName}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
