import { useRef, useEffect } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';

export default function HeroSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const overlineRef = useRef<HTMLSpanElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  // Particle system — golden dust in sunlight
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let w = window.innerWidth;
    let h = window.innerHeight;
    canvas.width = w;
    canvas.height = h;

    const isMobile = w < 768;
    const particleCount = isMobile ? 30 : 70;

    interface Particle {
      x: number;
      y: number;
      r: number;
      vx: number;
      vy: number;
      opacity: number;
      pulseSpeed: number;
      pulseOffset: number;
    }

    const particles: Particle[] = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h * 0.7,
        r: Math.random() * 2.5 + 0.5,
        vx: (Math.random() - 0.5) * 0.15,
        vy: -Math.random() * 0.15 - 0.025,
        opacity: Math.random() * 0.5 + 0.1,
        pulseSpeed: Math.random() * 0.01 + 0.0025,
        pulseOffset: Math.random() * Math.PI * 2,
      });
    }

    let mx = 0;
    const onMouseMove = (e: MouseEvent) => {
      mx = (e.clientX / w - 0.5) * 2;
    };
    window.addEventListener('mousemove', onMouseMove);

    let animId: number;
    const draw = (time: number) => {
      animId = requestAnimationFrame(draw);
      ctx.clearRect(0, 0, w, h);

      particles.forEach(p => {
        p.x += p.vx + mx * 0.15;
        p.y += p.vy;

        // Wrap around
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h * 0.7 + 10;
        if (p.y > h * 0.7 + 10) p.y = -10;

        const pulse = Math.sin(time * p.pulseSpeed + p.pulseOffset) * 0.3 + 0.7;
        const alpha = p.opacity * pulse;

        // Glow
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
        g.addColorStop(0, `rgba(232, 200, 138, ${alpha})`);
        g.addColorStop(0.4, `rgba(192, 138, 69, ${alpha * 0.4})`);
        g.addColorStop(1, 'rgba(192, 138, 69, 0)');

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2);
        ctx.fillStyle = g;
        ctx.fill();

        // Core
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(244, 239, 230, ${alpha * 0.9})`;
        ctx.fill();
      });
    };

    animId = requestAnimationFrame(draw);

    const onResize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w;
      canvas.height = h;
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  // Parallax on background
  useEffect(() => {
    const bg = bgRef.current;
    if (!bg) return;
    const onMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * -15;
      const y = (e.clientY / window.innerHeight - 0.5) * -8;
      bg.style.transform = `scale(1.08) translate(${x}px, ${y}px)`;
    };
    window.addEventListener('mousemove', onMove);
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  // GSAP entrance
  useEffect(() => {
    const tl = gsap.timeline({ delay: 0.4 });
    tl.fromTo(overlineRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' })
      .fromTo(titleRef.current, { opacity: 0, y: 50, scale: 0.95 }, { opacity: 1, y: 0, scale: 1, duration: 1.2, ease: 'power3.out' }, '-=0.5')
      .fromTo(subtitleRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, '-=0.6')
      .fromTo(ctaRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, '-=0.4');
    return () => { tl.kill(); };
  }, []);

  return (
    <section id="hero" className="relative w-full min-h-[100dvh] overflow-hidden bg-charcoal">
      {/* Background image with parallax */}
      <div
        ref={bgRef}
        className="absolute inset-0 transition-transform duration-700 ease-out"
        style={{ transform: 'scale(1.08)' }}
      >
        <img
          src="/assets/hero-bg.jpg"
          alt="BILAGUN"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Dark gradient overlays for readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/30 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-charcoal/60 via-transparent to-charcoal/40" />

      {/* Sun rays — CSS animated */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute top-[-20%] right-[10%] w-[600px] h-[600px] md:w-[900px] md:h-[900px] rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(192,138,69,0.4) 0%, rgba(232,200,138,0.15) 30%, transparent 70%)',
            animation: 'pulse-glow 6s ease-in-out infinite',
          }}
        />
        {/* Animated light shafts */}
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className="absolute top-0 pointer-events-none"
            style={{
              left: `${35 + i * 15}%`,
              width: '2px',
              height: '100%',
              background: `linear-gradient(180deg, rgba(192,138,69,${0.08 - i * 0.02}) 0%, transparent 60%)`,
              transform: `rotate(${-8 + i * 6}deg)`,
              transformOrigin: 'top center',
              animation: `ray-shift ${8 + i * 2}s ease-in-out infinite alternate`,
            }}
          />
        ))}
      </div>

      {/* Particle canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* Vignette */}
      <div
        className="absolute inset-0 pointer-events-none z-10"
        style={{
          boxShadow: 'inset 0 0 150px 60px rgba(23, 21, 18, 0.5)',
        }}
      />

      {/* Content */}
      <div className="relative z-20 flex flex-col items-center justify-end min-h-[100dvh] text-center px-6 pb-24 md:pb-32">
        <span
          ref={overlineRef}
          className="font-manrope text-[11px] md:text-xs uppercase tracking-[0.25em] text-gold mb-5 opacity-0"
          style={{ textShadow: '0 2px 12px rgba(192,138,69,0.4), 0 0 4px rgba(192,138,69,0.2)' }}
        >
          {t.hero.overline}
        </span>

        <h1
          ref={titleRef}
          className="font-cinzel text-[52px] md:text-[90px] lg:text-[130px] tracking-[0.1em] text-bone leading-none opacity-0"
          style={{
            textShadow: '0 4px 40px rgba(23,21,18,0.6), 0 0 80px rgba(192,138,69,0.15)',
          }}
        >
          {t.hero.title}
        </h1>

        <p
          ref={subtitleRef}
          className="mt-6 max-w-[480px] font-manrope text-sm md:text-base text-bone/75 leading-relaxed opacity-0"
          style={{ textShadow: '0 2px 12px rgba(23,21,18,0.5)' }}
        >
          {t.hero.subtitle}
        </p>

        <div ref={ctaRef} className="mt-10 flex flex-col sm:flex-row gap-4 opacity-0">
          <button
            onClick={() => document.getElementById('tree')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-primary"
            data-cursor-hover
          >
            {t.hero.cta1}
          </button>
          <button
            onClick={() => document.getElementById('history')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-secondary border-bone/30 text-bone hover:bg-bone/10 hover:border-bone/50"
            data-cursor-hover
          >
            {t.hero.cta2}
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 opacity-40">
        <div className="w-px h-8 bg-gradient-to-b from-transparent to-gold/70" />
        <span className="font-manrope text-[9px] uppercase tracking-[0.2em] text-bone/50">
          {t.hero.scroll}
        </span>
      </div>

      {/* CSS animations */}
      <style>{`
        @keyframes pulse-glow {
          0%, 100% { transform: scale(1); opacity: 0.15; }
          50% { transform: scale(1.15); opacity: 0.25; }
        }
        @keyframes ray-shift {
          0% { opacity: 0.04; transform: rotate(var(--r, -8deg)) translateX(0); }
          100% { opacity: 0.1; transform: rotate(var(--r, -8deg)) translateX(20px); }
        }
      `}</style>
    </section>
  );
}
