import { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface TreeNode {
  name: string;
  gen: string;
  year: string;
  traits: string[];
  x: number;
  y: number;
  image: string;
}

const treeNodes: TreeNode[] = [
  { name: 'Juma de Bi Lagun', gen: '0', year: '2009', traits: ['LOE 1885611', 'VA(E)'], x: 50, y: 90, image: '/assets/tree-argo.jpg' },
  { name: 'Yuma de Bi Lagun', gen: 'I', year: '2011', traits: ['LOE 2019472', 'V'], x: 30, y: 68, image: '/assets/tree-nora.jpg' },
  { name: 'Farah de Bi Lagun', gen: 'I', year: '2010', traits: ['Hija de Juma'], x: 70, y: 68, image: '/assets/tree-rex.jpg' },
  { name: 'Yanke de Bi Lagun', gen: 'I', year: '2010', traits: ['Hijo de Juma'], x: 85, y: 68, image: '/assets/tree-max.jpg' },
  { name: 'Korah de Bi Lagun', gen: 'II', year: '2013', traits: ['V', 'IPO1'], x: 10, y: 46, image: '/assets/tree-alba.jpg' },
  { name: 'Kiss de Bi Lagun', gen: 'II', year: '2013', traits: ['AK(E)', 'SG'], x: 25, y: 46, image: '/assets/tree-luna.jpg' },
  { name: 'Kenzo de Bi Lagun', gen: 'II', year: '2015', traits: ['AK(E)', 'SG'], x: 40, y: 46, image: '/assets/kenzo-card.jpg' },
  { name: 'Halfa de Bi Lagun', gen: 'II', year: '2014', traits: ['AK(P)', 'SG'], x: 55, y: 46, image: '/assets/marck-card.jpg' },
  { name: 'Russo de Bi Lagun', gen: 'II', year: '2014', traits: ['Hijo de Yuma'], x: 70, y: 46, image: '/assets/gallery-2.jpg' },
  { name: 'Solo de Bi Lagun', gen: 'III', year: '2018', traits: ['Joven'], x: 45, y: 24, image: '/assets/gallery-4.jpg' },
  { name: 'Owen de Bi Lagun', gen: 'III', year: '2018', traits: ['Joven'], x: 60, y: 24, image: '/assets/gallery-5.jpg' },
  { name: 'Raisha de Arances', gen: 'II', year: '2012', traits: ['Hija de Farah'], x: 85, y: 46, image: '/assets/gallery-6.jpg' },
];

const connections = [
  { from: 0, to: 1 }, { from: 0, to: 2 }, { from: 0, to: 3 },
  { from: 1, to: 4 }, { from: 1, to: 5 }, { from: 1, to: 6 }, { from: 1, to: 7 }, { from: 1, to: 8 },
  { from: 7, to: 9 }, { from: 7, to: 10 },
  { from: 2, to: 11 },
];

export default function TreeSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const sectionRef = useRef<HTMLElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const nodesWrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    gsap.fromTo(el.querySelector('.tree-header'), { opacity: 0, y: 40 }, {
      opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });

    const lines = svgRef.current?.querySelectorAll('line');
    lines?.forEach((line, i) => {
      gsap.fromTo(line, { attr: { 'stroke-dashoffset': 500 }, opacity: 0 }, {
        attr: { 'stroke-dashoffset': 0 }, opacity: 1, duration: 1.2, delay: 0.2 + i * 0.12, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 60%', toggleActions: 'play none none none' }
      });
    });

    const nodes = nodesWrapRef.current?.querySelectorAll('.tree-node');
    nodes?.forEach((node, i) => {
      gsap.fromTo(node, { opacity: 0, scale: 0.4 }, {
        opacity: 1, scale: 1, duration: 0.7, delay: 0.4 + i * 0.1, ease: 'back.out(1.4)',
        scrollTrigger: { trigger: el, start: 'top 60%', toggleActions: 'play none none none' }
      });
    });
  }, []);

  return (
    <section id="tree" ref={sectionRef} className="relative py-24 md:py-32 bg-charcoal overflow-hidden">
      <div className="container-main">
        <div className="tree-header text-center mb-12 md:mb-16">
          <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
            {t.tree.overline}
          </span>
          <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
            {t.tree.title}
          </h2>
          <p className="mt-4 font-manrope text-sm md:text-base text-bone/40 max-w-[480px] mx-auto">
            {t.tree.subtitle}
          </p>
        </div>

        <div className="relative w-full max-w-[900px] mx-auto aspect-[1/1.4] md:aspect-[1/1.1]">
          <svg ref={svgRef} className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
            {connections.map((c, idx) => {
              const from = treeNodes[c.from];
              const to = treeNodes[c.to];
              return (
                <line
                  key={idx}
                  x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                  stroke="#C08A45" strokeWidth="0.12"
                  strokeDasharray="500" strokeDashoffset="500"
                  opacity={0}
                />
              );
            })}
          </svg>

          <div className="absolute left-0 top-0 bottom-0 w-8 hidden md:flex flex-col justify-around pointer-events-none">
            <span className="font-cinzel text-[9px] text-gold/30 tracking-wider text-center">III</span>
            <span className="font-cinzel text-[9px] text-gold/30 tracking-wider text-center">II</span>
            <span className="font-cinzel text-[9px] text-gold/30 tracking-wider text-center">I</span>
            <span className="font-cinzel text-[9px] text-gold/30 tracking-wider text-center">0</span>
          </div>

          <div ref={nodesWrapRef} className="absolute inset-0">
            {treeNodes.map((node) => (
              <div
                key={node.name}
                className="tree-node absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group opacity-0 z-0 hover:z-[50]"
                style={{ left: `${node.x}%`, top: `${node.y}%` }}
              >
                <div className="hidden md:block absolute -inset-3 rounded-full border border-gold/15 group-hover:border-gold/50 group-hover:shadow-[0_0_30px_rgba(192,138,69,0.25)] transition-all duration-500" />

                <div className="relative w-11 h-11 md:w-16 md:h-16 lg:w-18 lg:h-18 rounded-full overflow-hidden border border-gold/30 md:border-2 group-hover:border-gold group-hover:scale-110 group-active:border-gold group-active:scale-110 transition-all duration-400">
                  <img src={node.image} alt={node.name} className="w-full h-full object-cover" loading="lazy" />
                </div>

                <div className="hidden md:block absolute top-full left-1/2 -translate-x-1/2 mt-2 text-center whitespace-nowrap opacity-60 group-hover:opacity-100 transition-opacity">
                  <span className="font-cinzel text-[9px] md:text-[10px] text-gold tracking-wider">{node.gen}</span>
                  <p className="font-manrope text-[9px] md:text-[10px] text-bone/70">{node.name}</p>
                </div>

                <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-3 w-40 md:w-48 opacity-0 group-hover:opacity-100 group-active:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 group-active:translate-y-0">
                  <div className="p-3 md:p-4 text-center rounded-xl border border-gold/40 shadow-[0_12px_48px_rgba(0,0,0,0.7)]" style={{ background: 'rgba(23, 21, 18, 0.94)', backdropFilter: 'blur(16px) saturate(140%)' }}>
                    <div className="w-9 h-9 md:w-11 md:h-11 mx-auto rounded-full overflow-hidden border border-gold/40 mb-2">
                      <img src={node.image} alt={node.name} className="w-full h-full object-cover" />
                    </div>
                    <span className="font-cinzel text-[10px] text-gold tracking-wider">{node.gen} &middot; {node.year}</span>
                    <p className="font-cinzel text-xs text-bone mt-0.5">{node.name}</p>
                    <div className="flex flex-wrap justify-center gap-1 mt-2">
                      {node.traits.map(trait => (
                        <span key={trait} className="font-manrope text-[9px] text-gold bg-gold/15 px-1.5 py-0.5 rounded-sm">{trait}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
