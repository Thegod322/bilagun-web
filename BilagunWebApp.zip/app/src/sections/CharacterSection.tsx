import { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Heart, Brain, Shield, Scale, Dna } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const icons = [Heart, Brain, Shield, Scale, Dna];

export default function CharacterSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const cards = el.querySelectorAll('.trait-card');
    gsap.fromTo(cards, { opacity: 0, y: 40 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.12, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 70%', toggleActions: 'play none none none' }
    });
  }, []);

  return (
    <section id="character" ref={sectionRef} className="py-24 md:py-40 bg-charcoal overflow-hidden">
      <div className="container-main">
        <div className="text-center mb-16">
          <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
            {t.character.overline}
          </span>
          <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
            {t.character.title}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-[900px] mx-auto">
          {t.character.traits.map((trait, i) => {
            const Icon = icons[i];
            return (
              <div
                key={trait.title}
                className="trait-card glass-card p-6 md:p-8 hover:border-gold/40 hover:shadow-[0_20px_60px_rgba(192,138,69,0.1)] transition-all duration-500 group"
              >
                <div className="w-10 h-10 rounded-full border border-gold/30 flex items-center justify-center mb-5 group-hover:border-gold/60 group-hover:shadow-[0_0_12px_rgba(192,138,69,0.2)] transition-all duration-300">
                  <Icon size={18} className="text-gold/70 group-hover:text-gold transition-colors" />
                </div>
                <h3 className="font-cinzel text-lg text-bone mb-2">{trait.title}</h3>
                <p className="font-manrope text-sm text-bone/50 leading-relaxed">{trait.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
