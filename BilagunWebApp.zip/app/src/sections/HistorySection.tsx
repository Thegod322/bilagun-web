import { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function HistorySection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const sectionRef = useRef<HTMLElement>(null);
  const overlineRef = useRef<HTMLSpanElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const tl = gsap.timeline({
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });
    tl.fromTo(overlineRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' })
      .fromTo(titleRef.current, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, '-=0.4')
      .fromTo(textRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, '-=0.4');
    return () => { tl.kill(); };
  }, []);

  return (
    <section id="history" ref={sectionRef} className="relative py-24 md:py-40 bg-bone overflow-hidden">
      {/* Decorative paper texture feel with subtle gold line */}
      <div className="absolute top-0 left-0 right-0 h-px gold-divider" />

      <div className="container-main max-w-[900px] mx-auto text-center">
        <span ref={overlineRef} className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-6 opacity-0">
          {t.history.overline}
        </span>

        <h2 ref={titleRef} className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-charcoal leading-tight opacity-0">
          {t.history.title}
        </h2>

        <p ref={textRef} className="mt-8 font-manrope text-base md:text-lg text-steel leading-[1.8] max-w-[680px] mx-auto opacity-0">
          {t.history.text}
        </p>

        <div className="mt-12 flex justify-center">
          <div className="w-16 h-16 border border-gold/30 rounded-full flex items-center justify-center">
            <span className="font-cinzel text-xl text-gold">B</span>
          </div>
        </div>
      </div>
    </section>
  );
}
