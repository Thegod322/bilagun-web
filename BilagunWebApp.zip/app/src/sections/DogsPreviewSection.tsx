import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useEffect, useRef } from 'react';
import { dogs } from '@/data/dogs';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function DogsPreviewSection() {
  const { lang } = useLanguage();
  const navigate = useNavigate();
  const sectionRef = useRef<HTMLElement>(null);

  const featuredDogs = dogs.slice(0, 4);

  const titleText = lang === 'es' ? 'Nuestros Perros' : lang === 'en' ? 'Our Dogs' : 'Наши собаки';
  const subtitleText = lang === 'es'
    ? 'Conoce a cada miembro de la dinastía BILAGUN'
    : lang === 'en'
    ? 'Meet every member of the BILAGUN dynasty'
    : 'Познакомьтесь с каждым членом династии BILAGUN';
  const ctaText = lang === 'es' ? 'Ver todos los perros' : lang === 'en' ? 'View all dogs' : 'Все собаки';

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const cards = el.querySelectorAll('.dog-preview-card');
    gsap.fromTo(cards, { y: 40 }, {
      y: 0, duration: 0.6, stagger: 0.1, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });
  }, []);

  return (
    <section ref={sectionRef} className="py-24 md:py-32 bg-charcoal overflow-hidden">
      <div className="container-main max-w-[1100px]">
        <div className="text-center mb-12">
          <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
            BILAGUN
          </span>
          <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
            {titleText}
          </h2>
          <p className="mt-3 font-manrope text-sm text-bone/45 max-w-[440px] mx-auto">
            {subtitleText}
          </p>
        </div>

        {/* Mobile: 2 cards */}
        <div className="dogs-grid-mobile">
          {featuredDogs.slice(0, 2).map(dog => (
            <div key={`m-${dog.slug}`} className="dog-preview-card group cursor-pointer" onClick={() => navigate(`/perro/${dog.slug}`)}>
              <div className="aspect-[3/4] overflow-hidden rounded-xl border border-gold/10 group-hover:border-gold/35 transition-all duration-500">
                <img src={dog.image} alt={dog.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
              </div>
              <div className="mt-3 text-center">
                <span className="font-cinzel text-sm text-bone group-hover:text-gold transition-colors">{dog.name}</span>
                <p className="font-manrope text-[10px] text-bone/35 mt-0.5">{dog.generation} Gen · {dog.birthDate.split('-')[0]}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop: 4 cards */}
        <div className="dogs-grid-desktop">
          {featuredDogs.map(dog => (
            <div key={`d-${dog.slug}`} className="dog-preview-card group cursor-pointer" onClick={() => navigate(`/perro/${dog.slug}`)}>
              <div className="aspect-[3/4] overflow-hidden rounded-xl border border-gold/10 group-hover:border-gold/35 transition-all duration-500">
                <img src={dog.image} alt={dog.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
              </div>
              <div className="mt-3 text-center">
                <span className="font-cinzel text-sm text-bone group-hover:text-gold transition-colors">{dog.name}</span>
                <p className="font-manrope text-[10px] text-bone/35 mt-0.5">{dog.generation} Gen · {dog.birthDate.split('-')[0]}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <button
            onClick={() => navigate('/perros')}
            className="btn-primary inline-flex items-center gap-2"
          >
            {ctaText}
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
