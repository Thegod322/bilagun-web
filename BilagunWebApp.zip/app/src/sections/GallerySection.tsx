import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import Lightbox from '@/components/Lightbox';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

type FilterType = 'all' | 'portraits' | 'nature' | 'shows';

const galleryItems = [
  { src: '/assets/tree-argo.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/gallery-5.jpg', cat: 'nature' as FilterType },
  { src: '/assets/gallery-3.jpg', cat: 'shows' as FilterType },
  { src: '/assets/tree-nora.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/gallery-4.jpg', cat: 'nature' as FilterType },
  { src: '/assets/kenzo-card.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/gallery-6.jpg', cat: 'nature' as FilterType },
  { src: '/assets/marck-card.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/tree-rex.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/tree-alba.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/tree-max.jpg', cat: 'portraits' as FilterType },
  { src: '/assets/tree-luna.jpg', cat: 'portraits' as FilterType },
];

const filterKeys: FilterType[] = ['all', 'portraits', 'nature', 'shows'];

export default function GallerySection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const [filter, setFilter] = useState<FilterType>('all');
  const [lightbox, setLightbox] = useState<{ images: string[]; index: number } | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const filtered = filter === 'all' ? galleryItems : galleryItems.filter(i => i.cat === filter);
  const allImages = galleryItems.map(i => i.src);

  // Split into groups of 3 for the repeating pattern
  const groups: typeof filtered[] = [];
  for (let i = 0; i < filtered.length; i += 3) {
    groups.push(filtered.slice(i, i + 3));
  }

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    gsap.fromTo(el.querySelector('.gallery-header'), { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });
  }, []);

  useEffect(() => {
    const list = listRef.current;
    if (!list) return;
    gsap.fromTo(list.querySelectorAll('.gallery-block'), { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.08, ease: 'power3.out'
    });
  }, [filter]);

  return (
    <section id="gallery" ref={sectionRef} className="py-24 md:py-32 bg-bone overflow-hidden">
      {/* Header */}
      <div className="gallery-header text-center mb-10 px-6">
        <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
          {t.gallery.overline}
        </span>
        <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-charcoal leading-tight">
          {t.gallery.title}
        </h2>
        <div className="mt-6 flex justify-center gap-8">
          {filterKeys.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`font-manrope text-xs uppercase tracking-[0.08em] pb-1 border-b transition-all duration-300 ${
                filter === f ? 'text-charcoal border-charcoal' : 'text-steel/60 border-transparent hover:text-charcoal hover:border-steel/30'
              }`}
            >
              {t.gallery.filters[f]}
            </button>
          ))}
        </div>
      </div>

      {/* Repeating pattern blocks */}
      <div ref={listRef} className="px-[2px] space-y-[2px]">
        {groups.map((group, groupIdx) => {
          const isReversed = groupIdx % 2 === 1; // odd groups are reversed
          return (
            <div
              key={groupIdx}
              className="gallery-block grid grid-cols-2 gap-[2px]"
              style={{ gridTemplateRows: '1fr 1fr' }}
            >
              {isReversed ? (
                <>
                  {/* Reversed: tall left (2 rows), 2 small right */}
                  {group[0] && (
                    <div
                      className="row-span-2 relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[0].src) })}
                    >
                      <img src={group[0].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                  {group[1] && (
                    <div
                      className="relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px', aspectRatio: '1/1' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[1].src) })}
                    >
                      <img src={group[1].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                  {group[2] && (
                    <div
                      className="relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px', aspectRatio: '1/1' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[2].src) })}
                    >
                      <img src={group[2].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                </>
              ) : (
                <>
                  {/* Normal: 2 small left, tall right */}
                  {group[0] && (
                    <div
                      className="relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px', aspectRatio: '1/1' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[0].src) })}
                    >
                      <img src={group[0].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                  {group[1] && (
                    <div
                      className="row-span-2 relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[1].src) })}
                    >
                      <img src={group[1].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                  {group[2] && (
                    <div
                      className="relative cursor-pointer overflow-hidden group"
                      style={{ borderRadius: '6px', aspectRatio: '1/1' }}
                      onClick={() => setLightbox({ images: allImages, index: allImages.indexOf(group[2].src) })}
                    >
                      <img src={group[2].src} alt="" className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/15 transition-colors duration-500" style={{ borderRadius: '6px' }} />
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom line */}
      <div className="mt-12 flex justify-center px-6">
        <div className="w-16 h-px bg-gold/40" />
      </div>

      <Lightbox
        images={lightbox?.images || []}
        currentIndex={lightbox?.index || 0}
        isOpen={!!lightbox}
        onClose={() => setLightbox(null)}
        onPrev={() => setLightbox(prev => prev ? { ...prev, index: (prev.index - 1 + prev.images.length) % prev.images.length } : null)}
        onNext={() => setLightbox(prev => prev ? { ...prev, index: (prev.index + 1) % prev.images.length } : null)}
      />
    </section>
  );
}
