import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, MapPin, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const sectionRef = useRef<HTMLElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setTimeout(() => setStatus('success'), 1500);
  };

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const tl = gsap.timeline({
      scrollTrigger: { trigger: el, start: 'top 75%', toggleActions: 'play none none none' }
    });
    tl.fromTo(el.querySelector('.contact-info'), { opacity: 0, x: -30 }, { opacity: 1, x: 0, duration: 0.8, ease: 'power3.out' })
      .fromTo(el.querySelector('.contact-form'), { opacity: 0, x: 30 }, { opacity: 1, x: 0, duration: 0.8, ease: 'power3.out' }, '-=0.5');
    return () => { tl.kill(); };
  }, []);

  return (
    <section id="contact" ref={sectionRef} className="py-24 md:py-40 bg-forest/20 overflow-hidden">
      <div className="container-main">
        <div className="flex flex-col lg:flex-row gap-16 lg:gap-20 max-w-[1000px] mx-auto">
          <div className="contact-info lg:w-2/5">
            <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
              {t.contact.overline}
            </span>
            <h2 className="font-cinzel text-[28px] md:text-[44px] text-bone leading-tight">
              {t.contact.title}
            </h2>
            <p className="mt-6 font-manrope text-base text-bone/60 leading-relaxed">
              {t.contact.text}
            </p>
            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-3">
                <Mail size={16} className="text-gold/60" />
                <span className="font-manrope text-sm text-bone/70">info@bilagun.com</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin size={16} className="text-gold/60" />
                <span className="font-manrope text-sm text-bone/70">España</span>
              </div>
            </div>
          </div>

          <div className="contact-form lg:w-3/5">
            {status === 'success' ? (
              <div className="flex flex-col items-center justify-center h-full min-h-[300px]">
                <div className="w-14 h-14 rounded-full bg-forest flex items-center justify-center mb-4">
                  <Check size={28} className="text-gold" />
                </div>
                <p className="font-manrope text-bone">{t.contact.form.success}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <input type="text" placeholder={t.contact.form.name} required className="w-full bg-charcoal border border-gold/15 text-bone px-5 py-4 rounded-lg placeholder:text-bone/30 font-manrope text-sm focus:border-gold/40 focus:outline-none transition-colors" />
                <input type="email" placeholder={t.contact.form.email} required className="w-full bg-charcoal border border-gold/15 text-bone px-5 py-4 rounded-lg placeholder:text-bone/30 font-manrope text-sm focus:border-gold/40 focus:outline-none transition-colors" />
                <textarea rows={5} placeholder={t.contact.form.message} required className="w-full bg-charcoal border border-gold/15 text-bone px-5 py-4 rounded-lg placeholder:text-bone/30 font-manrope text-sm focus:border-gold/40 focus:outline-none transition-colors resize-none" />
                <button type="submit" disabled={status === 'loading'} className="btn-primary w-full">
                  {status === 'loading' ? <div className="w-5 h-5 border-2 border-charcoal/30 border-t-charcoal rounded-full animate-spin" /> : t.contact.form.submit}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
