import { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function BreedSection() {
  const { lang } = useLanguage();
  const t = translations[lang];
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const tl = gsap.timeline({
      scrollTrigger: { trigger: el, start: 'top 70%', toggleActions: 'play none none none' }
    });
    tl.fromTo(el.querySelector('.breed-text'), { opacity: 0, x: -40 }, { opacity: 1, x: 0, duration: 0.8, ease: 'power3.out' })
      .fromTo(el.querySelector('.breed-image'), { opacity: 0, x: 40 }, { opacity: 1, x: 0, duration: 0.8, ease: 'power3.out' }, '-=0.5');
    return () => { tl.kill(); };
  }, []);

  return (
    <section id="breed" ref={sectionRef} className="py-24 md:py-40 bg-forest/30 overflow-hidden">
      <div className="container-main">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          <div className="breed-text lg:w-1/2">
            <span className="inline-block font-manrope text-[11px] uppercase tracking-[0.15em] text-gold mb-4">
              {t.breed.overline}
            </span>
            <h2 className="font-cinzel text-[28px] md:text-[44px] lg:text-[56px] text-bone leading-tight">
              {t.breed.title}
            </h2>
            <p className="mt-6 font-manrope text-base md:text-lg text-bone/60 leading-[1.8]">
              {t.breed.text}
            </p>
            <div className="mt-8 flex gap-6">
              {[
                { label: 'Altura', value: '55-65cm' },
                { label: 'Peso', value: '22-40kg' },
                { label: 'Esperanza', value: '9-13años' },
              ].map(stat => (
                <div key={stat.label}>
                  <span className="font-cinzel text-xl text-gold">{stat.value}</span>
                  <p className="font-manrope text-[10px] uppercase tracking-wider text-bone/40 mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="breed-image lg:w-1/2 flex justify-center">
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full border border-gold/20 flex items-center justify-center">
                <div className="w-52 h-52 md:w-64 md:h-64 rounded-full border border-gold/10 flex items-center justify-center overflow-hidden">
                  <img src="/assets/rufo-portrait.jpg" alt="German Shepherd" className="w-full h-full object-cover opacity-80" loading="lazy" />
                </div>
              </div>
              <div className="absolute -inset-4 rounded-full border border-gold/5" />
              {/* Decorative dots */}
              {[0, 90, 180, 270].map(deg => (
                <div key={deg} className="absolute w-2 h-2 rounded-full bg-gold/40" style={{
                  top: '50%', left: '50%',
                  transform: `rotate(${deg}deg) translate(160px) translate(-50%, -50%)`
                }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
