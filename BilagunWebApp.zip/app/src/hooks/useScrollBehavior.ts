import { useEffect, useRef } from 'react';

const HOME_SCROLL_KEY = 'bilagun-home-scroll';

/**
 * Для главной страницы: сохраняет скролл при уходе, восстанавливает при возврате
 */
export function useHomeScrollRestore() {
  const hasRestored = useRef(false);

  useEffect(() => {
    // Restore scroll position on mount (when coming back from dogs page)
    if (!hasRestored.current) {
      const saved = sessionStorage.getItem(HOME_SCROLL_KEY);
      if (saved) {
        const y = parseInt(saved, 10);
        requestAnimationFrame(() => {
          window.scrollTo(0, y);
        });
        hasRestored.current = true;
      }
    }

    // Save scroll position before leaving
    const handleBeforeUnload = () => {
      sessionStorage.setItem(HOME_SCROLL_KEY, String(window.scrollY));
    };

    // Also save on scroll (throttled implicitly by just reading latest on nav)
    const saveScroll = () => {
      sessionStorage.setItem(HOME_SCROLL_KEY, String(window.scrollY));
    };

    window.addEventListener('scroll', saveScroll, { passive: true });

    return () => {
      handleBeforeUnload();
      window.removeEventListener('scroll', saveScroll);
    };
  }, []);
}

/**
 * Для внутренних страниц: скроллит наверх при открытии
 */
export function useScrollToTop() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
}
