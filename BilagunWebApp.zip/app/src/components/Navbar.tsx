import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import translations from '@/translations';
import { Menu, X } from 'lucide-react';

const sections = ['hero', 'history', 'tree', 'character', 'breed', 'gallery', 'archive', 'contact'];

export default function Navbar() {
  const { lang, setLang } = useLanguage();
  const t = translations[lang];
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    if (!isHome) return;
    const onScroll = () => {
      setScrolled(window.scrollY > 50);
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.getBoundingClientRect().top <= 200) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [isHome]);

  useEffect(() => {
    if (isHome) {
      setScrolled(false);
    } else {
      setScrolled(true);
    }
  }, [location.pathname]);

  const scrollTo = (id: string) => {
    if (!isHome) {
      navigate('/');
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }, 300);
      return;
    }
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const lineageLabels = ['Origen', 'I', 'II', 'III', 'IV'];
  const sectionToLabel: Record<string, number> = {
    hero: 0, history: 1, tree: 1, character: 2, breed: 2, gallery: 3, archive: 3, contact: 4
  };
  const activeLabel = isHome ? (sectionToLabel[activeSection] ?? 0) : -1;

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled || !isHome ? 'bg-charcoal/90 backdrop-blur-xl border-b border-gold/10' : 'bg-transparent'}`}>
        <div className="container-main">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button onClick={() => navigate('/')} className="font-cinzel text-base md:text-lg tracking-[0.12em] text-bone hover:text-gold transition-colors">
              BILAGUN
            </button>

            <div className="hidden lg:flex items-center gap-8">
              {(['history', 'lineage', 'gallery', 'archive', 'contact'] as const).map((key) => {
                const sectionId = key === 'lineage' ? 'tree' : key;
                const isActive = isHome && activeSection === sectionId;
                return (
                  <button
                    key={key}
                    onClick={() => scrollTo(sectionId)}
                    className={`font-manrope text-[11px] uppercase tracking-[0.12em] transition-colors ${isActive ? 'text-gold' : 'text-bone/60 hover:text-bone'}`}
                  >
                    {t.nav[key]}
                  </button>
                );
              })}
              <button
                onClick={() => { setMenuOpen(false); navigate('/perros'); }}
                className={`font-manrope text-[11px] uppercase tracking-[0.12em] transition-colors ${!isHome ? 'text-gold' : 'text-bone/60 hover:text-bone'}`}
              >
                {lang === 'es' ? 'Perros' : lang === 'en' ? 'Dogs' : 'Собаки'}
              </button>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-1">
                {(['es', 'en', 'ru'] as const).map((l, i) => (
                  <span key={l} className="flex items-center">
                    {i > 0 && <span className="text-bone/20 mx-1 text-xs">|</span>}
                    <button
                      onClick={() => setLang(l)}
                      className={`font-cinzel text-[11px] tracking-wider transition-colors ${lang === l ? 'text-gold' : 'text-bone/40 hover:text-bone'}`}
                    >
                      {l.toUpperCase()}
                    </button>
                  </span>
                ))}
              </div>
              <button onClick={() => setMenuOpen(true)} className="lg:hidden text-bone">
                <Menu size={22} />
              </button>
            </div>
          </div>

          {/* Lineage progress bar */}
          {isHome && (
            <div className={`hidden md:flex items-center justify-center pb-3 gap-0 transition-opacity duration-300 ${scrolled ? 'opacity-100' : 'opacity-0'}`}>
              {lineageLabels.map((label, i) => (
                <div key={label} className="flex items-center">
                  <div className={`w-2 h-2 rounded-full transition-all duration-500 ${i <= activeLabel ? 'bg-gold shadow-[0_0_8px_rgba(192,138,69,0.6)]' : 'bg-bone/20'}`} />
                  <span className={`font-cinzel text-[9px] ml-1.5 mr-3 tracking-wider ${i <= activeLabel ? 'text-gold' : 'text-bone/30'}`}>{label}</span>
                  {i < lineageLabels.length - 1 && (
                    <div className={`w-8 h-px transition-colors duration-500 ${i < activeLabel ? 'bg-gold/50' : 'bg-bone/10'}`} />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Mobile overlay */}
      <div className={`fixed inset-0 z-[60] bg-charcoal flex flex-col items-center justify-center transition-all duration-500 ${menuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        <button onClick={() => setMenuOpen(false)} className="absolute top-5 right-6 text-bone"><X size={26} /></button>
        <div className="flex flex-col items-center gap-6">
          {(['history', 'lineage', 'gallery', 'archive', 'contact'] as const).map((key) => (
            <button
              key={key}
              onClick={() => { scrollTo(key === 'lineage' ? 'tree' : key); setMenuOpen(false); }}
              className="font-cinzel text-xl text-bone hover:text-gold transition-colors"
            >
              {t.nav[key]}
            </button>
          ))}
          <button
            onClick={() => { setMenuOpen(false); navigate('/perros'); }}
            className="font-cinzel text-xl text-bone hover:text-gold transition-colors"
          >
            {lang === 'es' ? 'Perros' : lang === 'en' ? 'Dogs' : 'Собаки'}
          </button>
        </div>
        <div className="flex items-center gap-6 mt-10">
          {(['es', 'en', 'ru'] as const).map((l) => (
            <button key={l} onClick={() => { setLang(l); }} className={`font-cinzel text-lg ${lang === l ? 'text-gold' : 'text-bone/40'}`}>{l.toUpperCase()}</button>
          ))}
        </div>
      </div>
    </>
  );
}
